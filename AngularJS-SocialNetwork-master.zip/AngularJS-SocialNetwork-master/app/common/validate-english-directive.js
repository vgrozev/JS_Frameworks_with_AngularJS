angular.module('socialNetwork.common.validation', [])
    .directive('validateEnglish', [function() {
        return {
            restrict: 'A',
            link: function(scope, element) {
                
            }
        }
    }]);